Want a secret lockable folder on Windows. Your in luck. We've got one.
This file is a .bat file, that means this will only run on Windows.
The password for this file should be "password". If not, type in 240408 when
you are prompted to unlock it.

To change the password, right click on the file and click on "Edit".
Then press Ctrl+F then type either "password" or "240408".
Then replace that with your new password then click save.
Open it up again and give it a try!

If you have any issues with this file please contact: asherwalter@aol.com

Thanks for downloading our app.

-Asher Walter (CEO of AsherTech)